#/usr/bin/env python

state = {
    players = [ {"name": "ai", "input": "", "predictor": False}, {"name": "human", "input" = "". "predictor": True} ]
    state = "input" # input, end
}

def flow
    return {m: "message", q:"question?"}

def main():
    print
    x = input()

if __name__ == '__main__':
    main()
