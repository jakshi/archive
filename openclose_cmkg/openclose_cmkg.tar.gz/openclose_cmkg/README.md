# openclose_cmkg
Open/Close hands game Chalat, Mayur, Kostiantyn, Gautam team
