#!/usr/bin/env ruby

require 'octokit'

# team ids list: client.org_teams('propertyguru').map { |team_object| team_object.id.to_s + ' ' + team_object.name}
TEAM_ID=2864564 # AllRepoView team

client = Octokit::Client.new(:access_token => '2b29b9472bdb4f1627a4abb6a0b7661a40461956')

client.user
client.auto_paginate = true

repos_names = client.org_repos('propertyguru', {:type => 'private'}).map { |repo_object| repo_object.name }

repos_names.each do |repo_name|
  client.add_team_repository(TEAM_ID, "propertyguru/#{repo_name}", permission: 'pull')
end
