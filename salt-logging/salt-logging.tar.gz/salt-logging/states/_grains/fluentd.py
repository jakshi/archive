#!/usr/bin/env python

import os

def main():
      # initialize a grains dictionary
      grains = {}
      # Some code for logic that sets grains like
      if os.path.isfile('/usr/local/bin/fluentd'):
          grains['fluentd'] = {'installed': True}
      else:
          grains['fluentd'] = {'installed': False}
      return grains
