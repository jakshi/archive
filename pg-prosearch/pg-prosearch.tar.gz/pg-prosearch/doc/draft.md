# Ideas

* restrict DB user to SELECT queries only
* restrict queries by LIMIT
* kill long running queries?

# Stack

# Backend

* Python
* SymmetricDS
* PostgreSQL

# Frontend

* Flask
* http://okfnlabs.org/recline/
* https://github.com/6pac/SlickGrid

# TODO

* Add: HTSQL

# References
## Misc

* https://github.com/sloria/cookiecutter-flask
* https://github.com/vinta/awesome-python
* https://github.com/humiaozuzu/awesome-flask

## Backend

* https://www.sqlalchemy.org/features.html

## Frontend

* http://okfnlabs.org/recline/docs/
* https://github.com/mattfullerton/recline-view-slickgrid-demo
* https://github.com/6pac/SlickGrid

# Alternatives

* https://ckan.org/
