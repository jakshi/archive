(function($, window) {
}).call(this, jQuery, window);
