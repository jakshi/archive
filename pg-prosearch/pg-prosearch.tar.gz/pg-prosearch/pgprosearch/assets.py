# -*- coding: utf-8 -*-
"""Application assets."""
from flask_assets import Bundle, Environment

css = Bundle(
    'libs/bootstrap/dist/css/bootstrap.css',
    'libs/slickgrid/slick.grid.css',
    'css/style.css',
    'css/grid.css',
    'css/slickgrid.css',
    filters='cssmin',
    output='public/css/common.css'
)

js = Bundle(
    'libs/jQuery/dist/jquery.js',
    'libs/bootstrap/dist/js/bootstrap.js',
    'libs/slickgrid/lib/jquery-ui-1.8.16.custom.min.js',
    'libs/slickgrid/lib/jquery.event.drag-2.2.js',
    'libs/slickgrid/slick.core.js',
    'libs/slickgrid/slick.grid.js',
    'libs/slickgrid/plugins/slick.rowselectionmodel.js',
    'libs/slickgrid/plugins/slick.rowmovemanager.js',
    'libs/underscore/underscore.js',
    'libs/backbone/backbone.js',
    'libs/mustache.js/mustache.js',
    'js/plugins.js',
    'js/recline.js',
    filters='jsmin',
    output='public/js/common.js'
)

assets = Environment()

assets.register('js_all', js)
assets.register('css_all', css)
