#!/usr/bin/env ruby

require 'aws-sdk'
require 'settingslogic'

class Settings < Settingslogic
  source 'config.yml'
end

nodes = Settings.nodes
aws_config = Settings.aws_config
aws_config['access_key_id'] = ENV['TF_VAR_aws_dd_access_key']
aws_config['secret_access_key'] = ENV['TF_VAR_aws_dd_secret_key']
aws_config['aws_keypair_name'] = 'terraform-bootstrap'

def create_ec2(nodes, aws_config)
  nodes.each do |node, options|
    puts "create ec2 instance #{node}"
    Aws.config.update({
                        region: aws_config.region,
                        credentials: Aws::Credentials.new(aws_config.access_key_id, aws_config.secret_access_key)
                      })

    ec2 = Aws::EC2::Client.new
    instance = ec2.run_instances({
                                    dry_run: false,
                                    image_id: aws_config.ami,
                                    min_count: 1, # required
                                    max_count: 1, # required
                                    key_name: aws_config.aws_keypair_name,
                                    security_group_ids: [aws_config.sg],
                                    subnet_id: aws_config.subnet_id,
                                    instance_type: options['type'],
                                    monitoring: {
                                      enabled: false, # required
                                    },
                                    tag_specifications: [
                                      {
                                        resource_type: "instance",
                                        tags: [
                                          {
                                            key: "Name",
                                            value: node,
                                          },
                                        ],
                                      },
                                    ]
                                  })
    ec2.wait_until(:instance_status_ok, 
  end
end

def destroy_ec2(nodes, aws_config)
  puts "destroy ec2 instance"
end

case ARGV[0]
when 'create'
  create_ec2(nodes, aws_config)
when 'destroy'
  destroy_ec2(nodes, aws_config)
else
  puts "Unknown command"
end

# find_ids = []
# find_ids = ec2.describe_tags.tags.select { |tag| tag.value == instance_name }

# # Is instance with instance_name tag exist? if no - exit 0
# if find_ids.length > 0
#   instance_ids = find_ids.map { |id| id.resource_id }
#   puts "Instances to terminate is (are):"
#   instance_ids.each do |instance_id|
#     puts "Instance id for #{instance_name} is #{instance_id}"
#   end
# else
#   puts "Instance with #{instance_name} tag doesn't exist. Gracefully exit"
#   exit 0
# end

# # Removing the instance

# ec2.terminate_instances(instance_ids: instance_ids)
# ec2.wait_until(:instance_terminated, instance_ids: instance_ids )

# puts "Instance(s) with #{instance_name} tag was(were) removed."
