## 0.0.7

* Modify: Forked fluentd-plugin-logzio as it seems to be unsupported
* Fix: Encoding::UndefinedConversionError error="\"\\xE2\" from ASCII-8BIT to UTF-8
