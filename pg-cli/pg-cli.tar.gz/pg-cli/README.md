# pg-cli
Property Guru CLI based search util

## Installation

## Usage

Search for property:

```
pg-cli search "SELECT * FROM property WHERE iwantto="rent" LIMIT 10"
```
