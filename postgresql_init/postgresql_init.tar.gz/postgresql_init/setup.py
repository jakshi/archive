from setuptools import setup

setup(
    name='psql_init',
    version='0.1',
    py_modules=['psql_init'],
    install_requires=[
                'Click',
    ],
    entry_points='''
            [console_scripts]
            psql_init=psql_init:cli
        ''',
)
