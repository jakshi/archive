import click
import os

def validate_host(ctx, param, value):
    if value == None:
      raise click.BadParameter('Please specify a host for basebackup')
    return value

@click.group()
def cli():
    """CLI util for bootstrapping PG PostgreSQL servers."""
    pass

@cli.command()
@click.confirmation_option(prompt='Are you sure you want to drop the db?')
def rm_data():
    """Remove data dir."""
    click.echo('Remove all files fom PostgreSQL data dir.')
    os.system('rm -rf /var/lib/postgresql/9.5/data/*')

@cli.command()
@click.option('--host', callback=validate_host, help='PostgreSQL host to get a basebackup from.')
def get_bb(host):
    """Get base backup."""
    click.echo('Get base backup to data.new dir')
    os.system('su - postgres -c "pg_basebackup -h %s -D /var/lib/postgresql/9.5/data.new -U replication -v -P --xlog-method=stream"' % host)

@cli.command()
@click.option('--role', type=click.Choice(['master', 'slave']), help='PostgreSQL instance role master/slave.')
def apply_bb(role):
    """Replace current data with new basebackup files."""
    click.echo('Move files fom PostgreSQL data dir to data.old.')
    os.system('mv /var/lib/postgresql/9.5/data/ /var/lib/postgresql/9.5/data.old')
    click.echo('Rename basebackup data.new dir to data dir')
    os.system('mv /var/lib/postgresql/9.5/data.new /var/lib/postgresql/9.5/data; chown postgres:postgres /var/lib/postgresql/9.5/data')

if __name__ == '__main__':
    cli()
