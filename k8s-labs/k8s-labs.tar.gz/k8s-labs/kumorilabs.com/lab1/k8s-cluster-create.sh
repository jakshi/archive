#!/usr/bin/env bash

source ./k8s-cluster-config.sh

if aws s3api head-bucket --bucket "$KOPS_STATE_S3_BUCKET" --region "$CLUSTER_AWS_REGION" 2>/dev/null; then
    echo "$KOPS_STATE_S3_BUCKET exists already. nothing to do"
else
    aws s3api create-bucket --bucket "$KOPS_STATE_S3_BUCKET" --region "$CLUSTER_AWS_REGION" --versioning-configuration Status=Enabled --create-bucket-configuration LocationConstraint="$CLUSTER_AWS_REGION"
fi

kops create cluster \
     --name=${CLUSTER_FULL_NAME} \
     --zones=${CLUSTER_AWS_AZ} \
     --master-size="t3.medium" \
     --node-size="t3.medium" \
     --node-count="2" \
     --dns-zone=${DOMAIN_NAME} \
     --ssh-public-key="~/.ssh/id_rsa.pub" \
     --kubernetes-version="1.11.6"
