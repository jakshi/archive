#!/usr/bin/env bash

source ./k8s-cluster-config.sh

ID=$(uuidgen)

aws route53 create-hosted-zone --name "$HOSTED_ZONE" --caller-reference $ID | jq .DelegationSet.NameServers

aws route53 list-hosted-zones | jq ".HostedZones[] | select(.Name==\"$PARENT_HOSTED_ZONE.\") | .Id"
