#!/usr/bin/env bash

# Your domain name that is hosted in AWS Route 53
export DOMAIN_NAME="infrastructure-testing.k8s.guruestate.com"
export HOSTED_ZONE="k8s.guruestate.com"
export PARENT_HOSTED_ZONE="guruestate.com"

# Friendly name to use as an alias for your cluster
export CLUSTER_ALIAS="sg"

# Full DNS name of you cluster
export CLUSTER_FULL_NAME="${CLUSTER_ALIAS}.${DOMAIN_NAME}"

# AWS availability zone where the cluster will be created
export CLUSTER_AWS_REGION="ap-southeast-1"
export CLUSTER_AWS_AZ="ap-southeast-1a"

# Bucket for kops state file
export KOPS_STATE_S3_BUCKET="${CLUSTER_FULL_NAME}-state"
export KOPS_STATE_STORE="s3://${CLUSTER_FULL_NAME}-state"
