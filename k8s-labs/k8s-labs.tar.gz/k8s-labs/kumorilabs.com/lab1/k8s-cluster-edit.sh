#!/usr/bin/env bash

source ./k8s-cluster-config.sh

kops edit cluster ${CLUSTER_FULL_NAME}
