#!/usr/bin/env bash

source ./k8s-cluster-config.sh


