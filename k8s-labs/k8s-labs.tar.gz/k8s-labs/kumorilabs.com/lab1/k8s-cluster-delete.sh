#!/usr/bin/env bash

source ./k8s-cluster-config.sh

kops delete cluster ${CLUSTER_FULL_NAME} --yes

if aws s3api head-bucket --bucket "$KOPS_STATE_S3_BUCKET" --region "$CLUSTER_AWS_REGION" 2>/dev/null; then
    aws s3api delete-bucket --bucket "$KOPS_STATE_S3_BUCKET" --region "$CLUSTER_AWS_REGION"
else
    echo "$KOPS_STATE_S3_BUCKET doesn't exists. nothing to do"
fi
