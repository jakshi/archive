# TODO Ideas
## Konstantin

* Fix: for the deep green line add missed station
* Add: switch for the BTS/MRT lines
* Re-factor: add alternative location for the data, so our service can start without VPN
* Modify: change color code for the heatmap to: red -> high price, green -> median price, blue: low price
* Add: statistic about heatmap
* Modify: place buttons on the pannel
* Modify: move buttons to the left
* Modify: make price buttons looks like elevator buttons
* Add: Singapore
* Add: Malaysia and Indonesia
* Add: our own heatmap engine
