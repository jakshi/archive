const express = require('express');
const app     = express();
const pgp = new require('pg-promise');
const promise = require('bluebird'); // or any other Promise/A+ compatible library;
const heap    = require('heap');
const options = {
    promiseLib: promise // overriding the default (ES6 Promise);
};

const connection = {
    host: 'dd-postgres-master-elb-integration.guruestate.com', // 'localhost' is the default;
    port: 5432, // 5432 is the default;
    database: 'propertydb_th',
    user: 'appuser',
    password: 'yAwh9^T#2#Zn'
};
const db = pgp()(connection);
app.use(express.static("static"));
app.set("view engine", "pug");
app.set("views", "./views");

app.get("/", (request, response) => {
    response.render("index.jade", {title: "Heatmap"});
});

app.get("/points", (request, response) => {
    const params = request.query;

    const bounds = {
        NE: {
            longitude: params.longitude_NE,
            latitude: params.latitude_NE,
        },
        SW: {
            longitude: params.longitude_SW,
            latitude: params.latitude_SW,
        }
    };

    const min = params.min || 0;
    const max = params.max || 1;
    const NE_lon = bounds.NE.longitude;
    const NE_lat = bounds.NE.latitude;
    const SW_lon = bounds.SW.longitude;
    const SW_lat = bounds.SW.latitude;
//    // Added limit to make it lighter.
//    /** @todo Remove the limit when/if the whole query is production ready. **/
//    db
//        .any(`
//            SELECT latitude, longitude, price
//            FROM v_listing
//            WHERE
//                type_code = 'RENT'
//                AND status_code = 'ACT'
//                AND price >= ${min}
//                AND price <= ${max}
//                AND ST_Point(longitude, latitude) @ ST_MakeEnvelope(${NE_lon}, ${NE_lat}, ${SW_lon}, ${SW_lat}, 4326)
//            LIMIT 100
//        `)
//        .then((data) => {
//            response.json(generalize(data)); // print data;
//        });

    response.json(search(
        params.limit || 100,
        Number(SW_lon) || -1000,
        Number(SW_lat) || -1000,
        Number(NE_lon) || 1000,
        Number(NE_lat) || 1000,
        params.type || 'RENT',
        Number(params.bedrooms) || 2,
        Number(params.base_price) || 0,
        Number(params.threshold) || Number.MAX_SAFE_INTEGER / 2
    ));
});

/**
 * @deprecated Not used anymore, remove?
 */
app.get("/search", (request, response) => {
	let params = request.query;
	response.json(search(
		params.limit || 100,
		params.lon1 || -1000,
		params.lat1 || -1000,
		params.lon2 || 1000,
		params.lat2 || 1000,
		params.type || 'RENT',
        params.bedrooms || 2,
		params.base_price || 0,
		params.threshold || Number.MAX_SAFE_INTEGER / 2
	));
});

let points = [];

/**
 * deduplicate by type/lon/lat
 */
let seenPoints = [];
function pointIsSeen(point) {
	let key = point.type_code + "_" + point.lon.toFixed(4) + "_" + point.lat.toFixed(4); // uncool. just cut to 4th digit fixed point which approx 10 meters distance
	if (seenPoints[key]) {
		seenPoints[key].count++;
		seenPoints[key].price += point.price;
		return true;
	}
	seenPoints[key] = point;
	return false;
}

function loadBulk(offset) {
	console.log("loadBulk, offset = " + offset);
	var limit = 10000;

	db.any(`
         SELECT id, type_code, bedrooms, price, longitude, latitude
        FROM v_listing_active
        WHERE
            type_code IS NOT NULL
            AND bedrooms IS NOT NULL
            AND longitude IS NOT NULL
            AND latitude IS NOT NULL
            AND status_code = 'ACT'
            AND price > 1999
            AND property_type_code IN ('CONDO', 'TOWN', 'APT', 'BUNG')
        ORDER BY id
        LIMIT ${limit} OFFSET ${offset}
    `, [true])
	.then((data) => {
		for (let point of data) {
			point = {
				  id: point.id,
          type_code: point.type_code,
                bedrooms: point.bedrooms,
				lon: point.longitude,
				lat: point.latitude,
				count: 1,
				price: Math.floor(point.price),
			};
			if (pointIsSeen(point)) {
				continue;
			}
			points[points.length] = point;
		}
		if (data.length >= limit) {
			process.nextTick(() => { loadBulk(offset + limit) });
		} else {
			loaded();
		}
	})
    .catch(error => console.log(error));
}
process.nextTick(() => { loadBulk(0); });

function loaded() {
	console.log("loaded, normalizing");
	points = points.map(point => {point.price = point.price / point.count; return point;});
	console.log('normalized');
}

function search(limit, lon1, lat1, lon2, lat2, type_code, bedrooms, basePrice, threshold) {
	  console.log("search over " + points.length + " records");
	  console.log(limit, lon1, lat1, lon2, lat2, type_code, bedrooms, basePrice);
	  let lonAdd = Math.abs(lon2 - lon1) * 0.2;
	  let latAdd = Math.abs(lat2 - lat1) * 0.2;
    console.log("lonAdd: " + lonAdd + ", latAdd: " + latAdd)
    lon1 -= lonAdd; lon2 += lonAdd;
    lat1 -= latAdd; lat2 += latAdd;
	  let start = new Date();
	  let distances = new heap((a, b) => Math.abs(b.distance) - Math.abs(a.distance));
	  let currentMax = Number.MAX_SAFE_INTEGER;
	  let maxWeight = 0;
	  for (let point of points) {
		    if (point.type_code != type_code) {
			      continue;
		    }
        if (point.bedrooms != bedrooms) {
            continue;
        }
		    if (point.lon < lon1 || point.lon > lon2 || point.lat < lat1 || point.lat > lat2) {
			      continue;
		    }
        if (point.lat > 15) {
            console.log("lat1: " + lat1 + ", lat2:" + lat2);
            console.log(point);
        }
	      if (point.price < basePrice - threshold || point.price > basePrice + threshold) {
			      continue;
		    }
		    let distance = basePrice - point.price;
		    maxWeight = Math.max(maxWeight, distance);
		    if (Math.abs(distance) >= currentMax) {
			      continue;
		    }
		    distances.push({
			      id: point.id,
            distance: distance,
			      lat: point.lat,
			      lng: point.lon,
			      price: point.price,
		    });
		    while (distances.size() > limit) {
			      distances.pop();
			      currentMax = Math.abs(distances.top().distance);
		    }
	  }
	  console.log("search done in " + (new Date() - start) + ", " + distances.size() + " points found");
	  distances = distances.toArray().sort((b, a) => b.distance - a.distance);
	  let minDistance = distances.length ? distances.map((x) => x.distance).reduce((a, b) => a < b ? a : b) : 0;
	  let maxDistance = distances.length ? distances.map((x) => x.distance).reduce((a, b) => a > b ? a : b) : 1;
	  if (minDistance == maxDistance) {
		    maxDistance = minDistance + 1;
	  }
	  distances.map((x) => { x.weight = 5 * (1 + x.distance / (minDistance - maxDistance)); delete x.distance; return x; });
	  distances = distances.sort((b, a) => b.weight >  a.weight ? 1 : -1);
    return distances;
}

function generalize(points) {
    let newPoints = new Map();
    for (let point of points) {
        let lon = point.longitude.toFixed(5), lat = point.latitude.toFixed(5);
        let key = String(lat) + '|' + String(lon);
        let prices = newPoints.get(key) || [];
        prices.push(parseInt(point.price));
        newPoints.set(key, prices);
    }

    let pointsToReturn = [];
    newPoints.forEach((v, i) => {
        var sum = v.reduce((a, b) => a + b);
        let avg = sum / v.length;
        let coords = i.split('|');
        pointsToReturn.push({
            lat: parseFloat(coords[0]),
            lon: parseFloat(coords[1]),
            weight: Math.round(avg)
        });
    });

    return pointsToReturn;

}
//
// south: 13.476173132690436,
// west: 100.12219260937502,
// north: 13.876478408290303,
// east: 101.09997581250002
app.listen(8000);
