var thresholds = {
    5000:   5000,
    10000:  5000,
    15000:  5000,
    20000:  5000,
    25000:  5000,
    30000:  5000,
    35000:  5000,
    40000:  5000,
    45000:  5000,
    50000:  5000,
    75000:  25000,
    100000: 25000,
    150000: 50000,
};

function loadPoints(heatmap, map) {
    var bedrooms = window.state.bedrooms;
    var basePrice = window.state.basePrice;
    var threshold = thresholds[basePrice];
    var bounds = map.getBounds().toJSON();
    var request = `longitude_NE=${bounds.east}&latitude_NE=${bounds.north}&longitude_SW=${bounds.west}&latitude_SW=${bounds.south}&limit=10000&bedrooms=${bedrooms}&base_price=${basePrice}&threshold=${threshold}&type_code=RENT`;

    fetch(`/points?${request}`)
        .then(response => response.json())
        .then(data => {
            heatmap.setData(rearrangeData(data));
            heatmap.setOptions({
                radius: (map.getZoom() - 10) * 6
            });
        });
}

function rearrangeData(data) {
    data = data.map(x => {return {location : new google.maps.LatLng(x.lat, x.lng), weight: x.weight}});
    return data;
}
function initMap()
{

    var map = new google.maps.Map(document.getElementById("map"), {
        center: {lat: 13.733114025479866, lng: 100.58327506787114},
        zoom: 11,
        mapTypeControlOptions: {position: google.maps.ControlPosition.TOP_RIGHT}
    });

    var ctaLayer = new google.maps.KmlLayer({
        url: 'http://jakshi.com/bangkok_bts_mrt_kml/bangkok_bts_mrt_line.kml?a=2',
        map: map
    });

    var heatmap = new google.maps.visualization.HeatmapLayer({
            map: map,
            data: [],
            maxIntensity: 50,
            opacity: 0.6
        }
//        {
//            // radius should be small ONLY if scaleRadius is true (or small radius is intended)
//            "radius": 0.01,
//            "maxOpacity": 0.4,
//            // scales the radius based on map zoom
//            "scaleRadius": true,
//            // if set to false the heatmap uses the global maximum for colorization
//            // if activated: uses the data maximum within the current map boundaries
//            //   (there will always be a red spot with useLocalExtremas true)
//            "useLocalExtrema": true,
//            blur: .6,
//            // which field name in your data represents the latitude - default "lat"
//            latField: 'lat',
//            // which field name in your data represents the longitude - default "lng"
//            lngField: 'lng',
//            // which field name in your data represents the data value - default "value"
//            valueField: 'weight'
//        }
    );

    window.map = map;
    map.addListener('dragend', (() => loadPoints(heatmap, map)));
    map.addListener('zoom_changed', (() => loadPoints(heatmap, map)));
    map.addListener('bounds_changed', (() => loadPoints(heatmap, map)));
    map.addListener('resize', (() => loadPoints(heatmap, map)));
    loadPoints(heatmap, map);
}

window.onload = initMap;

window.state = {
    basePrice: 5000,
    bedrooms:  2
};

function updateUi()
{
    $("button.update-price")
        .removeClass("active")
        .each(function () {
            var $this = $(this);

            if (window.state.basePrice == $this.data("base-price")) {
                $this.addClass("active");
                return;
            }
        });

    $("button.update-bedrooms")
        .removeClass("active")
        .each(function () {
            var $this = $(this);

            if (window.state.bedrooms == $this.data("bedrooms")) {
                $this.addClass("active");
                return;
            }
        });
}

$(function () {
    $("button.update-price").on("click", function () {
        if (window.map) {
            window.state.basePrice = $(this).data("base-price");
            google.maps.event.trigger(map, "resize"); // Invalidate the map.
            updateUi();
        }
    });

    $("button.update-bedrooms").on("click", function () {
        if (window.map) {
            window.state.bedrooms = $(this).data("bedrooms");
            google.maps.event.trigger(map, "resize"); // Invalidate the map.
            updateUi();
        }
    });

    updateUi();
});
