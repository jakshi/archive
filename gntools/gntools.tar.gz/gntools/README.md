Micro utils for managing ganeti nodes

# create.py
Creates ganeti nodes from yaml config
