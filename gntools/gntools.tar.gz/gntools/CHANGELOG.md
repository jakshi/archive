# 0.0.5

* Add: --no-install switch

# 0.0.4

Add: printing ganeti CLI command that will be used for instance creation

# 0.0.3

Fix: bug with python 2.x and python 3.x using different commands to read from standart input.

# 0.0.2

* Add: requirements.txt file
* Add: printing configuration of instance that is planned to create
* Add: asking confirmation to create an instance
* Add: support of KVM virtualization to instance creation script
