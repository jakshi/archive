# Someday

* Add: adding PCI path-through and assign GPU core to KVM instance
* Add: write a salt cloud module on base of this micro-utils

# v0.3.0

* Add: tests

# v0.2.0

* Re-factor: package as a wheel package

# v0.1.0

* Re-factor: Switch to using ganeti API. https://github.com/MostAwesomeDude/gentleman can be used
* Re-factor: Switch to using some CLI util library

# v0.0.8

* Add: utils config

# v0.0.7

* Add: config directory

# v0.0.6

* Add: '-a' key to the util that will ask confirmation before proceed
* Add: '-v' key to toggle will util print what it plan to do or not
